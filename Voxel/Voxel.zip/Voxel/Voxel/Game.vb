﻿Imports Voxel.Voxel.Drawing
Public Class Game
    Public a(60, 60, 60) As Cube

    Dim Xh As Integer
    Dim Yh As Integer
    Dim Zh As Integer

    Public Sub Load()
        For z = 0 To 60 - 1
            For y = 0 To 60 - 1
                For x = 0 To 60 - 1
                    a(x, y, z) = New Cube() With {.Exists = False}
                Next
            Next
        Next

        For y = 0 To 60 - 1
            For x = 0 To 60 - 1
                Dim z As Integer ' = Math.Sin(1 / 2 * x ^ 2 - 1 / 4 * y ^ 2 + 3) * Math.Cos(2 * x + 1 - Math.Exp(y))
                a(x, y, z).Exists = True
                a(x, y, z).c = Color.FromArgb(x * 255 / 60, y * 255 / 60, z * 255 / 60)
            Next
        Next
    End Sub
    Public Function RenderFile(filepath As String)
        Dim js = Newtonsoft.Json.JsonConvert.DeserializeObject(IO.File.ReadAllText(filepath))
        For Each j In js!voxels
            If TypeOf j Is Newtonsoft.Json.Linq.JObject Then
                If Not j("x") Is Nothing Then
                    ' a(j!x, j!y, j!z) = (New Cube() With {.c = Color.FromArgb(255 * j!x / 60, 255 * j!y / 60, 255 * j!z / 60), .Exists = True})
                    a(j!x, j!y, j!z) = (New Cube() With {.c = Color.FromArgb(j!red, j!green, j!blue), .Exists = True})
                    If Xh < j!x Then
                        Xh = j!x
                    End If
                    If Yh < j!x Then
                        Yh = j!y
                    End If
                    If Zh < j!z Then
                        Zh = j!z
                    End If
                End If
            End If
        Next
        Xh /= 2
        Yh /= 2
        Zh /= 2
    End Function
    Public Class Cube
        Public c As Color
        Public Exists As Boolean = False
    End Class
    Dim rrr As Double = 0
    Dim aa As axis = 0
    Public Sub Tick()
        Dim cmm = cm(rrr, aa)
        For z = 0 To 60 - 1
            For y = 0 To 60 - 1
                For x = 0 To 60 - 1
                    If a(x, y, z).Exists Then
                        Select Case aa
                            Case axis.x
                                rotate(rrr, cmm, x, y, z, a(x, y, z).c, 0, Yh, Zh)
                            Case axis.y
                                rotate(rrr, cmm, x, y, z, a(x, y, z).c, Xh, 0, Zh)
                            Case axis.z
                                rotate(rrr, cmm, x, y, z, a(x, y, z).c, Xh, Yh, 0)
                            Case axis.scale
                                rotate(rrr, cmm, x, y, z, a(x, y, z).c)
                        End Select
                    End If
                Next
            Next
        Next

        'If rrr > 2 Then
        '    rrr = -4
        '    aa += 1
        '    aa = aa Mod 4
        'Else
        '    rrr += 0.1

        'End If
    End Sub
    Public Function rotate(t As Double, m As Object, x As Integer, y As Integer, z As Integer, c As Color, Optional ox As Integer = 0, Optional oy As Integer = 0, Optional oz As Integer = 0)
        x -= ox
        y -= oy
        z -= oz
        Draw((m(0, 0) * x) + m(0, 1) * y + (m(0, 2) * z) + ox, (m(1, 0) * x) + (m(1, 1) * y) + (m(1, 2) * z) + oy, (m(2, 0) * x) + (m(2, 1) * y) + (m(2, 2) * z) + oz, c)
    End Function
    Public Function cm(t As Double, a As axis)
        Select Case a
            Case axis.x
                Return {{1, 0, 0, 0},
                        {0, Math.Cos(t), Math.Sin(t), 0},
                        {0, -Math.Sin(t), Math.Cos(t), 0},
                        {0, 0, 0, 1}}
            Case axis.y
                Return {{Math.Cos(t), 0, Math.Sin(t), 0},
                        {0, 1, 0, 0},
                        {-Math.Sin(t), 0, Math.Cos(t), 0},
                        {0, 0, 0, 1}}
            Case axis.z
                Return {{Math.Cos(t), -Math.Sin(t), 0, 0},
                       {Math.Sin(t), Math.Cos(t), 0, 0},
                       {0, 0, 1, 0},
                       {0, 0, 0, 1}}
            Case axis.scale
                Return {{t, 0, 0},
                        {0, t, 0},
                        {0, 0, t}}
        End Select
    End Function
    Public Enum axis
        x
        y
        z
        scale
    End Enum
End Class